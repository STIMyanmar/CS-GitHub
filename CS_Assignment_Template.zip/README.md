# AI Assignment 1

Author: [Student Name]
Student ID: 102301

## Instructions
Complete the `main.py` file to classify basic AI models.

## Submission
Push all updates before the deadline. Include your final report in `/docs`.
